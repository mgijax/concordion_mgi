package spec.concordion.results.breadcrumbs;

public class BreadcrumbsTest extends AbstractBreadcrumbsTestCase {

    public void setUpResource(String resourceName, String content) {
        super.setUpResource(resourceName, content);
    }
    
    public Result getBreadcrumbsFor(String resourceName) throws Exception {
        return super.getBreadcrumbsFor(resourceName);
    }
}