package spec.concordion.results.assertEquals.failure;

public class EmptyTest extends FailureTest {

}
