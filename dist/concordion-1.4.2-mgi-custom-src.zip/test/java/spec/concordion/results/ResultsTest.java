package spec.concordion.results;

import org.concordion.integration.junit3.ConcordionTestCase;

public class ResultsTest extends ConcordionTestCase {
}
