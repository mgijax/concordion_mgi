package test.concordion.compiler;

public interface DiagnosticMessage {

    String getMessage();
}

