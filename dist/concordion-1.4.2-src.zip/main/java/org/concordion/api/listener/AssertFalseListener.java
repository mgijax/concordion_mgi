package org.concordion.api.listener;


public interface AssertFalseListener extends AssertListener {

}
