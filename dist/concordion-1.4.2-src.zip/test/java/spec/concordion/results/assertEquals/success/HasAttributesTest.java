package spec.concordion.results.assertEquals.success;


public class HasAttributesTest extends SuccessTest {
    
}
